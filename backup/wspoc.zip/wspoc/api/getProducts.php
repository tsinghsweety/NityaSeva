<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$returnObj = {
  "name": "vikas",
  "rollNo": 29
};
 ?>
